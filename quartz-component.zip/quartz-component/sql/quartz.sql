CREATE DATABASE /*!32312 IF NOT EXISTS*/`quartz-vue` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `quartz-vue`;

-- ----------------------------
-- 1、存储每一个已配置的 jobDetail 的详细信息
-- ----------------------------

SET FOREIGN_KEY_CHECKS = 0; 
DROP TABLE IF EXISTS QUARTZ_JOB_DETAILS;
SET FOREIGN_KEY_CHECKS = 1; 
CREATE TABLE QUARTZ_JOB_DETAILS (
    sched_name           VARCHAR(120)    NOT NULL,
    job_name             VARCHAR(200)    NOT NULL,
    job_group            VARCHAR(200)    NOT NULL,
    description          VARCHAR(250)    NULL,
    job_class_name       VARCHAR(250)    NOT NULL,
    is_durable           VARCHAR(1)      NOT NULL,
    is_nonconcurrent     VARCHAR(1)      NOT NULL,
    is_update_data       VARCHAR(1)      NOT NULL,
    requests_recovery    VARCHAR(1)      NOT NULL,
    job_data             BLOB            NULL,
    PRIMARY KEY (sched_name,job_name,job_group)
) ENGINE=INNODB;

-- ----------------------------
-- 2、 存储已配置的 Trigger 的信息
-- ----------------------------

SET FOREIGN_KEY_CHECKS = 0; 
DROP TABLE IF EXISTS QUARTZ_TRIGGERS;
SET FOREIGN_KEY_CHECKS = 1; 
CREATE TABLE QUARTZ_TRIGGERS (
    sched_name           VARCHAR(120)    NOT NULL,
    trigger_name         VARCHAR(200)    NOT NULL,
    trigger_group        VARCHAR(200)    NOT NULL,
    job_name             VARCHAR(200)    NOT NULL,
    job_group            VARCHAR(200)    NOT NULL,
    description          VARCHAR(250)    NULL,
    next_fire_time       BIGINT(13)      NULL,
    prev_fire_time       BIGINT(13)      NULL,
    priority             INTEGER         NULL,
    trigger_state        VARCHAR(16)     NOT NULL,
    trigger_type         VARCHAR(8)      NOT NULL,
    start_time           BIGINT(13)      NOT NULL,
    end_time             BIGINT(13)      NULL,
    calendar_name        VARCHAR(200)    NULL,
    misfire_instr        SMALLINT(2)     NULL,
    job_data             BLOB            NULL,
    PRIMARY KEY (sched_name,trigger_name,trigger_group),
    FOREIGN KEY (sched_name,job_name,job_group) REFERENCES QUARTZ_JOB_DETAILS(sched_name,job_name,job_group)
) ENGINE=INNODB;

-- ----------------------------
-- 3、 存储简单的 Trigger，包括重复次数，间隔，以及已触发的次数
-- ----------------------------
DROP TABLE IF EXISTS QUARTZ_SIMPLE_TRIGGERS;
CREATE TABLE QUARTZ_SIMPLE_TRIGGERS (
    sched_name           VARCHAR(120)    NOT NULL,
    trigger_name         VARCHAR(200)    NOT NULL,
    trigger_group        VARCHAR(200)    NOT NULL,
    repeat_count         BIGINT(7)       NOT NULL,
    repeat_interval      BIGINT(12)      NOT NULL,
    times_triggered      BIGINT(10)      NOT NULL,
    PRIMARY KEY (sched_name,trigger_name,trigger_group),
    FOREIGN KEY (sched_name,trigger_name,trigger_group) REFERENCES QUARTZ_TRIGGERS(sched_name,trigger_name,trigger_group)
) ENGINE=INNODB;

-- ----------------------------
-- 4、 存储 Cron Trigger，包括 Cron 表达式和时区信息
-- ---------------------------- 
DROP TABLE IF EXISTS QUARTZ_CRON_TRIGGERS;
CREATE TABLE QUARTZ_CRON_TRIGGERS (
    sched_name           VARCHAR(120)    NOT NULL,
    trigger_name         VARCHAR(200)    NOT NULL,
    trigger_group        VARCHAR(200)    NOT NULL,
    cron_expression      VARCHAR(200)    NOT NULL,
    time_zone_id         VARCHAR(80),
    PRIMARY KEY (sched_name,trigger_name,trigger_group),
    FOREIGN KEY (sched_name,trigger_name,trigger_group) REFERENCES QUARTZ_TRIGGERS(sched_name,trigger_name,trigger_group)
) ENGINE=INNODB;

-- ----------------------------
-- 5、 Trigger 作为 Blob 类型存储(用于 Quartz 用户用 JDBC 创建他们自己定制的 Trigger 类型，JobStore 并不知道如何存储实例的时候)
-- ---------------------------- 
DROP TABLE IF EXISTS QUARTZ_BLOB_TRIGGERS;
CREATE TABLE QUARTZ_BLOB_TRIGGERS (
    sched_name           VARCHAR(120)    NOT NULL,
    trigger_name         VARCHAR(200)    NOT NULL,
    trigger_group        VARCHAR(200)    NOT NULL,
    blob_data            BLOB            NULL,
    PRIMARY KEY (sched_name,trigger_name,trigger_group),
    FOREIGN KEY (sched_name,trigger_name,trigger_group) REFERENCES QUARTZ_TRIGGERS(sched_name,trigger_name,trigger_group)
) ENGINE=INNODB;

-- ----------------------------
-- 6、 以 Blob 类型存储存放日历信息， quartz可配置一个日历来指定一个时间范围
-- ---------------------------- 
DROP TABLE IF EXISTS QUARTZ_CALENDARS;
CREATE TABLE QUARTZ_CALENDARS (
    sched_name           VARCHAR(120)    NOT NULL,
    calendar_name        VARCHAR(200)    NOT NULL,
    calendar             BLOB            NOT NULL,
    PRIMARY KEY (sched_name,calendar_name)
) ENGINE=INNODB;

-- ----------------------------
-- 7、 存储已暂停的 Trigger 组的信息
-- ---------------------------- 
DROP TABLE IF EXISTS QUARTZ_PAUSED_TRIGGER_GRPS;
CREATE TABLE QUARTZ_PAUSED_TRIGGER_GRPS (
    sched_name           VARCHAR(120)    NOT NULL,
    trigger_group        VARCHAR(200)    NOT NULL,
    PRIMARY KEY (sched_name,trigger_group)
) ENGINE=INNODB;

-- ----------------------------
-- 8、 存储与已触发的 Trigger 相关的状态信息，以及相联 Job 的执行信息
-- ---------------------------- 
DROP TABLE IF EXISTS QUARTZ_FIRED_TRIGGERS;
CREATE TABLE QUARTZ_FIRED_TRIGGERS (
    sched_name           VARCHAR(120)    NOT NULL,
    entry_id             VARCHAR(95)     NOT NULL,
    trigger_name         VARCHAR(200)    NOT NULL,
    trigger_group        VARCHAR(200)    NOT NULL,
    instance_name        VARCHAR(200)    NOT NULL,
    fired_time           BIGINT(13)      NOT NULL,
    sched_time           BIGINT(13)      NOT NULL,
    priority             INTEGER         NOT NULL,
    state                VARCHAR(16)     NOT NULL,
    job_name             VARCHAR(200)    NULL,
    job_group            VARCHAR(200)    NULL,
    is_nonconcurrent     VARCHAR(1)      NULL,
    requests_recovery    VARCHAR(1)      NULL,
    PRIMARY KEY (sched_name,entry_id)
) ENGINE=INNODB;

-- ----------------------------
-- 9、 存储少量的有关 Scheduler 的状态信息，假如是用于集群中，可以看到其他的 Scheduler 实例
-- ---------------------------- 
DROP TABLE IF EXISTS QUARTZ_SCHEDULER_STATE; 
CREATE TABLE QUARTZ_SCHEDULER_STATE (
    sched_name           VARCHAR(120)    NOT NULL,
    instance_name        VARCHAR(200)    NOT NULL,
    last_checkin_time    BIGINT(13)      NOT NULL,
    checkin_interval     BIGINT(13)      NOT NULL,
    PRIMARY KEY (sched_name,instance_name)
) ENGINE=INNODB;

-- ----------------------------
-- 10、 存储程序的悲观锁的信息(假如使用了悲观锁)
-- ---------------------------- 
DROP TABLE IF EXISTS QUARTZ_LOCKS;
CREATE TABLE QUARTZ_LOCKS (
    sched_name           VARCHAR(120)    NOT NULL,
    lock_name            VARCHAR(40)     NOT NULL,
    PRIMARY KEY (sched_name,lock_name)
) ENGINE=INNODB;

DROP TABLE IF EXISTS QUARTZ_SIMPROP_TRIGGERS;
CREATE TABLE QUARTZ_SIMPROP_TRIGGERS (
    sched_name           VARCHAR(120)    NOT NULL,
    trigger_name         VARCHAR(200)    NOT NULL,
    trigger_group        VARCHAR(200)    NOT NULL,
    str_prop_1           VARCHAR(512)    NULL,
    str_prop_2           VARCHAR(512)    NULL,
    str_prop_3           VARCHAR(512)    NULL,
    int_prop_1           INT             NULL,
    int_prop_2           INT             NULL,
    long_prop_1          BIGINT          NULL,
    long_prop_2          BIGINT          NULL,
    dec_prop_1           NUMERIC(13,4)   NULL,
    dec_prop_2           NUMERIC(13,4)   NULL,
    bool_prop_1          VARCHAR(1)      NULL,
    bool_prop_2          VARCHAR(1)      NULL,
    PRIMARY KEY (sched_name,trigger_name,trigger_group),
    FOREIGN KEY (sched_name,trigger_name,trigger_group) REFERENCES QUARTZ_TRIGGERS(sched_name,trigger_name,trigger_group)
) ENGINE=INNODB;

DROP TABLE IF EXISTS `sys_job`;
CREATE TABLE `sys_job` (
  `job_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '任务ID',
  `job_name` varchar(64) NOT NULL DEFAULT '' COMMENT '任务名称',
  `job_group` varchar(64) NOT NULL DEFAULT 'DEFAULT' COMMENT '任务组名',
  `invoke_target` varchar(500) NOT NULL COMMENT '调用目标字符串',
  `cron_expression` varchar(255) DEFAULT '' COMMENT 'cron执行表达式',
  `misfire_policy` varchar(20) DEFAULT '3' COMMENT '计划执行错误策略（1立即执行 2执行一次 3放弃执行）',
  `concurrent` char(1) DEFAULT '1' COMMENT '是否并发执行（0允许 1禁止）',
  `status` char(1) DEFAULT '0' COMMENT '状态（0正常 1暂停）',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT '' COMMENT '备注信息',
  PRIMARY KEY (`job_id`,`job_name`,`job_group`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8 COMMENT='定时任务调度表';


DROP TABLE IF EXISTS `sys_job_log`;
CREATE TABLE `sys_job_log` (
  `job_log_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '任务日志ID',
  `job_name` varchar(64) NOT NULL COMMENT '任务名称',
  `job_group` varchar(64) NOT NULL COMMENT '任务组名',
  `invoke_target` varchar(500) NOT NULL COMMENT '调用目标字符串',
  `job_message` varchar(500) DEFAULT NULL COMMENT '日志信息',
  `status` char(1) DEFAULT '0' COMMENT '执行状态（0正常 1失败）',
  `exception_info` varchar(2000) DEFAULT '' COMMENT '异常信息',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`job_log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='定时任务调度日志表';

COMMIT;