package com.ycsyxt.constants;

public class Constants {
    /**
     * 通用成功标识
     */
    public static final String SUCCESS = "0";

    /**
     * 通用失败标识
     */
    public static final String FAIL = "1";

    /**
     * 默认用户名
     */
    public static final String USER_NAME = "admin";
}
