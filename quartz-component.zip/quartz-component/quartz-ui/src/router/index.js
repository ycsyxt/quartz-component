import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router)

/**
 * Note: 路由配置项
 */

// 公共路由
export const routes = [
  {
    path: '/job',
    component: (resolve) => require(['@/views/job'], resolve),
  },
  {
    path: '/job/log',
    component: (resolve) => require(['@/views/job/log'], resolve),
  }
]

export default new Router({
  mode: 'history', // 去掉url中的#
  scrollBehavior: () => ({ y: 0 }),
  routes: routes
})
